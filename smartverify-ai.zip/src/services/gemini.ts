import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export interface VerificationResult {
  matchPercentage: number;
  fraudDetected: boolean;
  confidenceScore: number;
  details: string;
  documentType: string;
  extractedInfo: Record<string, any>;
  issues: string[];
}

export async function verifyDocument(
  documentBase64: string,
  signatureBase64?: string
): Promise<VerificationResult> {
  const model = "gemini-2.0-flash-exp"; // Using a fast, multi-modal model

  const prompt = `
    Analyze the uploaded document(s). 
    If a signature is provided separately, compare it with any signatures found on the document.
    
    Tasks:
    1. Identify the document type (ID, Passport, Proof of Address, etc.)
    2. Extract key information (Name, ID Number, Expiry Date, etc.)
    3. Detect any signs of fraud or tampering (digital manipulation, inconsistent fonts, mismatched photos).
    4. If a signature is provided, calculate a match percentage between the provided signature and the one on the document.
    5. Provide a confidence score (0-100) for the overall verification.
    6. Flag as fraud if any major discrepancies are found.

    Return the result in JSON format.
  `;

  const parts = [
    { text: prompt },
    {
      inlineData: {
        mimeType: "image/jpeg",
        data: documentBase64,
      },
    },
  ];

  if (signatureBase64) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: signatureBase64,
      },
    });
  }

  const response = await ai.models.generateContent({
    model,
    contents: [{ parts }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          matchPercentage: { type: Type.NUMBER },
          fraudDetected: { type: Type.BOOLEAN },
          confidenceScore: { type: Type.NUMBER },
          details: { type: Type.STRING },
          documentType: { type: Type.STRING },
          extractedInfo: { type: Type.OBJECT },
          issues: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["matchPercentage", "fraudDetected", "confidenceScore", "details", "documentType", "extractedInfo", "issues"],
      },
    },
  });

  return JSON.parse(response.text);
}
