import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '../lib/utils';

interface DocumentUploadProps {
  label: string;
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  accept?: Record<string, string[]>;
}

export const DocumentUpload: React.FC<DocumentUploadProps> = ({
  label,
  onFileSelect,
  selectedFile,
  accept = { 'image/*': ['.jpeg', '.jpg', '.png'], 'application/pdf': ['.pdf'] }
}) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFileSelect(acceptedFiles[0]);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    multiple: false
  } as any);

  return (
    <div className="flex flex-col gap-2">
      <label className="text-xs font-mono uppercase tracking-wider text-zinc-500">{label}</label>
      <div
        {...getRootProps()}
        className={cn(
          "relative group cursor-pointer border-2 border-dashed rounded-xl p-8 transition-all duration-200 flex flex-col items-center justify-center gap-4 min-h-[200px]",
          isDragActive ? "border-blue-500 bg-blue-50/50" : "border-zinc-200 hover:border-zinc-300 bg-zinc-50/50",
          selectedFile && "border-green-500 bg-green-50/30"
        )}
      >
        <input {...getInputProps()} />
        
        {selectedFile ? (
          <div className="flex flex-col items-center gap-2 text-center">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
              <CheckCircle2 size={24} />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-zinc-900 truncate max-w-[200px]">
                {selectedFile.name}
              </span>
              <span className="text-xs text-zinc-500">
                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
              </span>
            </div>
          </div>
        ) : (
          <>
            <div className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center transition-colors",
              isDragActive ? "bg-blue-100 text-blue-600" : "bg-zinc-100 text-zinc-400 group-hover:text-zinc-500"
            )}>
              <Upload size={24} />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-zinc-900">
                {isDragActive ? "Drop the file here" : "Click or drag file to upload"}
              </p>
              <p className="text-xs text-zinc-500 mt-1">
                Supports JPG, PNG, PDF (Max 10MB)
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
