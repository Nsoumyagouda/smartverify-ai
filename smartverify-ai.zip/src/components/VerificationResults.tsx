import React from 'react';
import { ShieldCheck, ShieldAlert, Info, Fingerprint, FileSearch, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import type { VerificationResult } from '../services/gemini';

interface VerificationResultsProps {
  result: VerificationResult;
}

export const VerificationResults: React.FC<VerificationResultsProps> = ({ result }) => {
  const isHighRisk = result.fraudDetected || result.confidenceScore < 70;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col gap-6"
    >
      {/* Status Header */}
      <div className={cn(
        "p-6 rounded-2xl border flex items-center gap-4",
        isHighRisk 
          ? "bg-red-50 border-red-100 text-red-900" 
          : "bg-green-50 border-green-100 text-green-900"
      )}>
        <div className={cn(
          "w-12 h-12 rounded-full flex items-center justify-center",
          isHighRisk ? "bg-red-100 text-red-600" : "bg-green-100 text-green-600"
        )}>
          {isHighRisk ? <ShieldAlert size={24} /> : <ShieldCheck size={24} />}
        </div>
        <div>
          <h3 className="text-lg font-bold">
            {isHighRisk ? "Verification Failed / High Risk" : "Verification Successful"}
          </h3>
          <p className="text-sm opacity-80">
            {result.details}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Confidence Score */}
        <div className="p-4 rounded-xl border border-zinc-200 bg-white">
          <div className="flex items-center gap-2 text-zinc-500 mb-2">
            <Fingerprint size={16} />
            <span className="text-xs font-mono uppercase tracking-wider">Confidence Score</span>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-zinc-900">{result.confidenceScore}%</span>
            <div className="flex-1 h-2 bg-zinc-100 rounded-full mb-2 overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${result.confidenceScore}%` }}
                className={cn(
                  "h-full rounded-full",
                  result.confidenceScore > 80 ? "bg-green-500" : result.confidenceScore > 50 ? "bg-yellow-500" : "bg-red-500"
                )}
              />
            </div>
          </div>
        </div>

        {/* Match Percentage */}
        <div className="p-4 rounded-xl border border-zinc-200 bg-white">
          <div className="flex items-center gap-2 text-zinc-500 mb-2">
            <FileSearch size={16} />
            <span className="text-xs font-mono uppercase tracking-wider">Signature Match</span>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-zinc-900">{result.matchPercentage}%</span>
            <div className="flex-1 h-2 bg-zinc-100 rounded-full mb-2 overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${result.matchPercentage}%` }}
                className={cn(
                  "h-full rounded-full",
                  result.matchPercentage > 90 ? "bg-green-500" : result.matchPercentage > 70 ? "bg-yellow-500" : "bg-red-500"
                )}
              />
            </div>
          </div>
        </div>

        {/* Document Type */}
        <div className="p-4 rounded-xl border border-zinc-200 bg-white">
          <div className="flex items-center gap-2 text-zinc-500 mb-2">
            <Info size={16} />
            <span className="text-xs font-mono uppercase tracking-wider">Document Type</span>
          </div>
          <span className="text-xl font-bold text-zinc-900 block mt-2">{result.documentType}</span>
        </div>
      </div>

      {/* Extracted Info & Issues */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl border border-zinc-200 bg-white">
          <h4 className="text-sm font-mono uppercase tracking-wider text-zinc-500 mb-4">Extracted Information</h4>
          <div className="space-y-3">
            {Object.entries(result.extractedInfo).map(([key, value]) => (
              <div key={key} className="flex justify-between items-center border-b border-zinc-50 pb-2">
                <span className="text-sm text-zinc-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                <span className="text-sm font-medium text-zinc-900">{String(value)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 rounded-2xl border border-zinc-200 bg-white">
          <h4 className="text-sm font-mono uppercase tracking-wider text-zinc-500 mb-4 flex items-center gap-2">
            <AlertTriangle size={16} className="text-yellow-500" />
            Detected Issues
          </h4>
          {result.issues.length > 0 ? (
            <ul className="space-y-2">
              {result.issues.map((issue, idx) => (
                <li key={idx} className="text-sm text-zinc-700 flex gap-2">
                  <span className="text-red-500">•</span>
                  {issue}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-zinc-400 italic">No issues detected.</p>
          )}
        </div>
      </div>
    </motion.div>
  );
};
