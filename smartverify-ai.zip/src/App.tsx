import React, { useState, useEffect } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import { Shield, FileCheck, History, Settings, LogOut, Search, Bell, Menu, X, Loader2, LogIn, Clock, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DocumentUpload } from './components/DocumentUpload';
import { VerificationResults } from './components/VerificationResults';
import { verifyDocument, type VerificationResult } from './services/gemini';
import { cn } from './lib/utils';
import { auth, db, googleProvider, signInWithPopup, signOut, onAuthStateChanged, collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, deleteDoc, doc, handleFirestoreError, OperationType } from './lib/firebase';
import { ErrorBoundary } from './components/ErrorBoundary';
import type { User } from 'firebase/auth';

type Tab = 'verification' | 'history';

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

function AppContent() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('verification');
  const [docFile, setDocFile] = useState<File | null>(null);
  const [sigFile, setSigFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) {
      setHistory([]);
      return;
    }

    const q = query(
      collection(db, 'verifications'),
      where('ownerUid', '==', user.uid),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setHistory(docs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'verifications');
    });

    return () => unsubscribe();
  }, [user]);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      toast.success("Signed in successfully");
    } catch (error) {
      console.error(error);
      toast.error("Sign in failed");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success("Signed out");
      setResult(null);
      setActiveTab('verification');
    } catch (error) {
      console.error(error);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64 = reader.result as string;
        resolve(base64.split(',')[1]);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const handleVerify = async () => {
    if (!docFile) {
      toast.error("Please upload a document first");
      return;
    }

    setIsProcessing(true);
    setResult(null);

    try {
      const docBase64 = await fileToBase64(docFile);
      const sigBase64 = sigFile ? await fileToBase64(sigFile) : undefined;

      const verificationResult = await verifyDocument(docBase64, sigBase64);
      setResult(verificationResult);
      
      if (user) {
        await addDoc(collection(db, 'verifications'), {
          ...verificationResult,
          ownerUid: user.uid,
          timestamp: serverTimestamp(),
          docFileName: docFile.name
        });
      }

      if (verificationResult.fraudDetected) {
        toast.error("Potential fraud detected!", { duration: 5000 });
      } else {
        toast.success("Verification complete");
      }
    } catch (error) {
      console.error(error);
      toast.error("Verification failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const deleteRecord = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'verifications', id));
      toast.success("Record deleted");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `verifications/${id}`);
    }
  };

  const reset = () => {
    setDocFile(null);
    setSigFile(null);
    setResult(null);
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-blue-600" size={32} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-2xl border border-zinc-200 shadow-xl max-w-md w-full text-center"
        >
          <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/20">
            <Shield size={32} />
          </div>
          <h1 className="text-2xl font-bold text-zinc-900 mb-2">SmartVerify AI</h1>
          <p className="text-zinc-500 mb-8">Secure document verification and fraud detection. Please sign in to continue.</p>
          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 px-6 py-3 bg-white border border-zinc-200 rounded-xl font-semibold text-zinc-700 hover:bg-zinc-50 transition-all shadow-sm"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
            Sign in with Google
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 flex text-zinc-900 font-sans">
      <Toaster position="top-right" />
      
      {/* Sidebar */}
      <aside className={cn(
        "bg-white border-r border-zinc-200 transition-all duration-300 flex flex-col",
        isSidebarOpen ? "w-64" : "w-20"
      )}>
        <div className="p-6 flex items-center gap-3 border-b border-zinc-100">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shrink-0">
            <Shield size={20} />
          </div>
          {isSidebarOpen && <span className="font-bold text-lg tracking-tight">SmartVerify</span>}
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <SidebarItem 
            icon={<FileCheck size={20} />} 
            label="Verification" 
            active={activeTab === 'verification'} 
            isSidebarOpen={isSidebarOpen} 
            onClick={() => setActiveTab('verification')}
          />
          <SidebarItem 
            icon={<History size={20} />} 
            label="History" 
            active={activeTab === 'history'} 
            isSidebarOpen={isSidebarOpen} 
            onClick={() => setActiveTab('history')}
          />
          <SidebarItem icon={<Bell size={20} />} label="Alerts" isSidebarOpen={isSidebarOpen} />
          <SidebarItem icon={<Settings size={20} />} label="Settings" isSidebarOpen={isSidebarOpen} />
        </nav>

        <div className="p-4 border-t border-zinc-100">
          <SidebarItem icon={<LogOut size={20} />} label="Logout" isSidebarOpen={isSidebarOpen} onClick={handleLogout} />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-zinc-200 flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-500"
            >
              <Menu size={20} />
            </button>
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
              <input 
                type="text" 
                placeholder="Search records..." 
                className="pl-10 pr-4 py-2 bg-zinc-100 border-transparent rounded-full text-sm focus:bg-white focus:border-blue-500 outline-none transition-all w-64"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-sm font-medium">{user.displayName || 'User'}</span>
              <span className="text-xs text-zinc-500">{user.email}</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-zinc-200 border border-zinc-300 overflow-hidden">
              <img src={user.photoURL || `https://picsum.photos/seed/${user.uid}/100/100`} alt="Avatar" referrerPolicy="no-referrer" />
            </div>
          </div>
        </header>

        {/* Dashboard Body */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-5xl mx-auto space-y-8">
            {activeTab === 'verification' ? (
              <>
                <header>
                  <h1 className="text-3xl font-bold tracking-tight text-zinc-900">Document Verification</h1>
                  <p className="text-zinc-500 mt-1">Upload documents and signatures for automated fraud detection.</p>
                </header>

                <AnimatePresence mode="wait">
                  {!result ? (
                    <motion.div 
                      key="upload"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="grid grid-cols-1 lg:grid-cols-2 gap-8"
                    >
                      <DocumentUpload 
                        label="Primary Document (ID, Passport, etc.)"
                        onFileSelect={setDocFile}
                        selectedFile={docFile}
                      />
                      <DocumentUpload 
                        label="Reference Signature (Optional)"
                        onFileSelect={setSigFile}
                        selectedFile={sigFile}
                      />
                      
                      <div className="lg:col-span-2 flex justify-center pt-4">
                        <button
                          onClick={handleVerify}
                          disabled={!docFile || isProcessing}
                          className={cn(
                            "px-8 py-4 rounded-xl font-bold text-white transition-all flex items-center gap-3 shadow-lg shadow-blue-500/20",
                            !docFile || isProcessing 
                              ? "bg-zinc-400 cursor-not-allowed" 
                              : "bg-blue-600 hover:bg-blue-700 active:scale-95"
                          )}
                        >
                          {isProcessing ? (
                            <>
                              <Loader2 className="animate-spin" size={20} />
                              Processing Document...
                            </>
                          ) : (
                            <>
                              <Shield size={20} />
                              Start Verification
                            </>
                          )}
                        </button>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="results"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                    >
                      <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold">Verification Results</h2>
                        <button 
                          onClick={reset}
                          className="text-sm font-medium text-blue-600 hover:text-blue-700 flex items-center gap-2"
                        >
                          <X size={16} />
                          Clear and New Upload
                        </button>
                      </div>
                      <VerificationResults result={result} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            ) : (
              <div className="space-y-6">
                <header>
                  <h1 className="text-3xl font-bold tracking-tight text-zinc-900">Verification History</h1>
                  <p className="text-zinc-500 mt-1">Review your past verification records and fraud reports.</p>
                </header>

                <div className="bg-white border border-zinc-200 rounded-2xl overflow-hidden">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50 border-b border-zinc-100">
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Document</th>
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Type</th>
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Status</th>
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Confidence</th>
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Date</th>
                        <th className="px-6 py-4 text-xs font-mono uppercase tracking-wider text-zinc-500">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-50">
                      {history.length > 0 ? history.map((record) => (
                        <tr key={record.id} className="hover:bg-zinc-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded bg-zinc-100 flex items-center justify-center text-zinc-400">
                                <FileCheck size={16} />
                              </div>
                              <span className="text-sm font-medium truncate max-w-[150px]">{record.docFileName || 'Unnamed Doc'}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-zinc-600">{record.documentType}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className={cn(
                              "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                              record.fraudDetected ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
                            )}>
                              {record.fraudDetected ? 'High Risk' : 'Verified'}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold">{record.confidenceScore}%</span>
                              <div className="w-16 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                                <div 
                                  className={cn("h-full", record.confidenceScore > 80 ? "bg-green-500" : "bg-yellow-500")}
                                  style={{ width: `${record.confidenceScore}%` }}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2 text-zinc-500">
                              <Clock size={14} />
                              <span className="text-xs">{record.timestamp?.toDate().toLocaleDateString()}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <button 
                              onClick={() => deleteRecord(record.id)}
                              className="p-2 text-zinc-400 hover:text-red-600 transition-colors"
                            >
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      )) : (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-zinc-400 italic">
                            No verification history found.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, active = false, isSidebarOpen, onClick }: { icon: React.ReactNode, label: string, active?: boolean, isSidebarOpen: boolean, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 p-3 rounded-xl transition-colors",
        active ? "bg-blue-50 text-blue-600" : "text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
      )}
    >
      <div className="shrink-0">{icon}</div>
      {isSidebarOpen && <span className="font-medium text-sm">{label}</span>}
    </button>
  );
}


